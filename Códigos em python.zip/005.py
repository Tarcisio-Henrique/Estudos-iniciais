n = int(input('Digite um número: '))
print('Analisando o valor de {}, seu antecessor é {} e o sucessor é {}.'.format(n, (n-1), (n+1)))