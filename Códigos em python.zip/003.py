num1 = int(input('Digite um número: '))
num2 = int(input('Digite mais um número: '))
soma = num1 + num2
# print('A soma entre', num1, 'e', num2, 'vale', soma)
print('A soma vale {}'.format(soma))