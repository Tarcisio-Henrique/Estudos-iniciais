nome = input('Digite o seu nome: ')
print('Seja bem vindo', nome,'!')

# nome = input('Digite o seu nome: ')
# print('Seja bem vindo {}!'.format(nome))