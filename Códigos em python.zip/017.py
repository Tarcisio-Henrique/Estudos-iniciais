'''co = float(input('Comptimento do cateto oposto: '))
ca = float(input('Comprimento do cateto adjacente: '))
hi = (co ** 2 + ca ** 2 ) ** (1/2)
print('A ipotenusa vai medir {:.2f}'.format(hi))'''

import math
co = float(input('Comprimento do cateto oposto: '))
ca = float(input('Comprimento do cateto adjascente: '))
hi = math.hypot(co, ca)
print('A iponetuna vai medir {:.2f}'.format(hi))